#ifndef WIN32
#  define BOOST_TEST_DYN_LINK
#endif
#define BOOST_TEST_MAIN
#define BOOST_TEST_MODULE aisdi_linear_tests
#include <boost/test/unit_test.hpp>
