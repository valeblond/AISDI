#ifndef AISDI_LINEAR_VECTOR_H
#define AISDI_LINEAR_VECTOR_H

#include <cstddef>
#include <initializer_list>
#include <stdexcept>

//#include <iostream>

namespace aisdi
{

template <typename Type>
class Vector
{
public:
    using difference_type = std::ptrdiff_t;
    using size_type = std::size_t;
    using value_type = Type;
    using pointer = Type*;
    using reference = Type&;
    using const_pointer = const Type*;
    using const_reference = const Type&;

    class ConstIterator;
    class Iterator;
    using iterator = Iterator;
    using const_iterator = ConstIterator;

    Vector()
    {
        first_empty = 0;
        cont_size = 0;
        array = nullptr;
    }

    Vector(std::initializer_list<Type> l)
    {
        first_empty = 0;
        cont_size = l.size();
        array = new Type[cont_size];

        for( auto it = l.begin(); it != l.end(); ++it )
            append( *it );
    }

    Vector(const Vector& other)
    {
        first_empty = 0;
        cont_size = other.getSize();
        array = new Type[cont_size];

        for( auto it = other.begin(); it != other.end(); ++it )
            append( *it );
    }

    Vector(Vector&& other)
    {
        first_empty = other.first_empty;
        cont_size = other.cont_size;
        array = other.array;

        other.array = nullptr;
        other.first_empty = 0;
        other.cont_size = 0;
    }

    ~Vector()
    {
        if( array != nullptr )
            delete[] array;
    }

    Vector& operator=(const Vector& other)
    {
        if( array == other.array )
            return *this;

        if( array != nullptr )
            delete[] array;

        array = nullptr;
        first_empty = 0;
        cont_size = 0;

        for( auto it = other.begin(); it != other.end(); ++it )
                append( *it );

        return *this;
    }

    Vector& operator=(Vector&& other)
    {
        if( array != nullptr )
            delete[] array;

        array = other.array;
        first_empty = other.first_empty;
        cont_size = other.cont_size;

        other.array = nullptr;
        other.first_empty = 0;
        other.cont_size = 0;

        return *this;
    }

    bool isEmpty() const
    {
        return (first_empty == 0);
    }

    size_type getSize() const
    {
        return first_empty;
    }

    void append(const Type& item)
    {
        if( cont_size-first_empty <= 0 )
            allocate_more_space();

        array[first_empty] = item;
        ++first_empty;
    }

    void prepend(const Type& item)
    {
        if( cont_size <= first_empty )
        {
            allocate_more_space( true );
        }
        else
        {
            for( size_type i = first_empty; i > 0; --i )
            {
                array[i] = array[i-1];
            }
        }
        ++first_empty;
        array[0] = item;
    }

    void insert(const const_iterator& insertPosition, const Type& item)
    {
        if( insertPosition.index_in_array > first_empty )
            throw std::out_of_range("insert(): there is no such a place in array");

        if( cont_size <= first_empty )
            allocate_more_space();

        for(size_type i = first_empty; i > insertPosition.index_in_array; --i)
        {
            array[i] = array[i-1];
        }
        ++first_empty;
        array[insertPosition.index_in_array] = item;
    }

    Type popFirst()
    {
        if( isEmpty() )
            throw std::logic_error("popFirst(): when empty collection");
        value_type tmp = array[0];

        for( size_type i = 1; i < first_empty; ++i )
            array[i-1] = array[i];

        --first_empty;

        return tmp;
    }

    Type popLast()
    {
        if( isEmpty() )
            throw std::logic_error("popLast(): when empty collection");
        return array[--first_empty];
    }

    void erase(const const_iterator& possition)
    {
        if( possition.index_in_array >= first_empty )
            throw std::out_of_range("erase(): out of range");

        --first_empty;
        for( size_type i = possition.index_in_array; i < first_empty; ++i )
            array[i] = array[i+1];
    }

    void erase(const const_iterator& firstIncluded, const const_iterator& lastExcluded)
    {

        /// If empty range do nothing
        if( firstIncluded == lastExcluded )
            return;

        /// First situation    [#,#,#, , , , , , ]

        if( firstIncluded.index_in_array == lastExcluded.index_in_array-1 )
        {
            erase(firstIncluded);
        }
        else if( (int) firstIncluded.index_in_array >= 0 && lastExcluded.index_in_array <= first_empty )
        {
            for( size_type i = firstIncluded.index_in_array, j = lastExcluded.index_in_array; j < first_empty; ++i, ++j )
            {
                array[i] = array[j];
            }
            first_empty -= lastExcluded.index_in_array - firstIncluded.index_in_array;
        }
        /// Else... OUT OF RANGE
        else
            throw std::out_of_range("erase(): out of range");
    }

    iterator begin()
    {
        return iterator(cbegin());
    }

    iterator end()
    {
        return iterator(cend());
    }

    const_iterator cbegin() const
    {
        const_iterator it;
        it.index_in_array = 0;
        it.ptr_to_element = array;
        it.ptr_to_vector = this;
        return it;
    }

    const_iterator cend() const
    {
        const_iterator it;
        it.index_in_array = first_empty;
        it.ptr_to_element = array+it.index_in_array;
        it.ptr_to_vector = this;
        return it;
    }

    const_iterator begin() const
    {
        return cbegin();
    }

    const_iterator end() const
    {
        return cend();
    }

private:
    value_type* array;

    size_type cont_size;
    size_type first_empty;

    static const size_type prelock_size = 1000;

    void allocate_more_space( bool first_element_empty = false )
    {
        value_type* tmp = new value_type[cont_size+prelock_size];

        for( size_type i = (first_element_empty ? 1 : 0), j = 0; j < cont_size; ++i, ++j )
            tmp[i] = array[j];

        cont_size += prelock_size;

        if( array != nullptr )
            delete[] array;

        array = tmp;
    }
};

template <typename Type>
class Vector<Type>::ConstIterator
{
friend class Vector;
public:
    using iterator_category = std::bidirectional_iterator_tag;
    using value_type = typename Vector::value_type;
    using difference_type = typename Vector::difference_type;
    using pointer = typename Vector::const_pointer;
    using reference = typename Vector::const_reference;

    explicit ConstIterator()
    {
        ptr_to_element = nullptr;
        ptr_to_vector = nullptr;
        index_in_array = 0;
    }

    reference operator*() const
    {
        if( (*this) == ptr_to_vector->cend() )
            throw std::out_of_range("Dereferencing: out of range");
        return *ptr_to_element;
    }

    ConstIterator& operator++()
    {
        if( (*this) == ptr_to_vector->cend() )
            throw std::out_of_range("++iterator: out of range");

        ++ptr_to_element;
        ++index_in_array;
        return *this;
    }

    ConstIterator operator++(int)
    {
        ConstIterator tmp = *this;
        ++(*this);
        return tmp;
    }

    ConstIterator& operator--()
    {
        if( (*this) == ptr_to_vector->cbegin() )
            throw std::out_of_range("--iterator: out of range");

        --ptr_to_element;
        --index_in_array;
        return *this;
    }

    ConstIterator operator--(int)
    {
        ConstIterator tmp = *this;
        --(*this);
        return tmp;
    }

    ConstIterator operator+(difference_type d) const
    {
        ConstIterator tmp = *this;
        tmp.ptr_to_element += d;
        tmp.index_in_array += d;

        return tmp;
    }

    ConstIterator operator-(difference_type d) const
    {
        ConstIterator tmp = *this;
        tmp.ptr_to_element -= d;
        tmp.index_in_array -= d;
        return tmp;
    }

    bool operator==(const ConstIterator& other) const
    {
        return ( ptr_to_vector == other.ptr_to_vector && ptr_to_element == other.ptr_to_element );
    }

    bool operator!=(const ConstIterator& other) const
    {
        return ( ptr_to_vector != other.ptr_to_vector || ptr_to_element != other.ptr_to_element );
    }

private:
    size_type index_in_array;
    const Vector<Type>* ptr_to_vector;
    pointer ptr_to_element;

};

template <typename Type>
class Vector<Type>::Iterator : public Vector<Type>::ConstIterator
{
public:
  using pointer = typename Vector::pointer;
  using reference = typename Vector::reference;

  explicit Iterator()
  {}

  Iterator(const ConstIterator& other)
    : ConstIterator(other)
  {}

  Iterator& operator++()
  {
    ConstIterator::operator++();
    return *this;
  }

  Iterator operator++(int)
  {
    auto result = *this;
    ConstIterator::operator++();
    return result;
  }

  Iterator& operator--()
  {
    ConstIterator::operator--();
    return *this;
  }

  Iterator operator--(int)
  {
    auto result = *this;
    ConstIterator::operator--();
    return result;
  }

  Iterator operator+(difference_type d) const
  {
    return ConstIterator::operator+(d);
  }

  Iterator operator-(difference_type d) const
  {
    return ConstIterator::operator-(d);
  }

  reference operator*() const
  {
    // ugly cast, yet reduces code duplication.
    return const_cast<reference>(ConstIterator::operator*());
  }
};

}

#endif // AISDI_LINEAR_VECTOR_H
