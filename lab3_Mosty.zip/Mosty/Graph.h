#ifndef GRAPH_H
#define GRAPH_H
#include <vector>
#include <fstream>
#include <string>
#include <stdexcept>
#include <iostream>

namespace aisdi
{

class Graph
{
  public:
    Graph(std::string fileName);
    Graph(unsigned int i);
    ~Graph();

    void addEdge(int v, int w);
    void printGraph();
    std::vector<std::pair<unsigned int,unsigned int>> bridges();

  private:
    std::size_t VCount;
    std::vector<unsigned int>* adjacent;

    bool isConnected(int w1 = -1, int w2 = -1);
    void go(unsigned int v, bool visited[], int w1 = -1, int w2 = -1);
};

}//namespace
#endif // GRAPH_H
