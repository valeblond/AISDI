#include "Graph.h"

namespace aisdi
{

Graph::Graph(std::string fileName)
: VCount(0), adjacent(nullptr)
{
  std::ifstream file;

  file.open(fileName); //open specified graph file to read information
  if(file.good())
  {
    int v, w;

    file >> VCount; //read number of vertices
    adjacent = new std::vector<unsigned int>[VCount]; //allocate memory for marking edges

    while(!file.eof()) //mark edges
    {
      file >> v >> w;
      addEdge(v,w);
    }
  }
  else
    throw std::out_of_range("could not open input file");

  file.close();
}

///////////////////////////////////////

Graph::Graph(unsigned int i)
: VCount(i), adjacent(nullptr)
{
    if(VCount!=0)
      adjacent = new std::vector<unsigned int>[VCount]; //allocate memory for marking edges
}

///////////////////////////////////////

Graph::~Graph()
{
  delete[] adjacent;
}

///////////////////////////////////////

void Graph::addEdge(int v, int w)
{
  if(!adjacent)
    throw std::out_of_range("adding edge to uninitialized graph");

  adjacent[v].push_back(w);
  adjacent[w].push_back(v);
}

///////////////////////////////////////

void Graph::printGraph()
{
  std::cout << "Vertices: " << VCount << std::endl;
  std::cout << "Adjacencies: " << std::endl;
  for(unsigned int i=0;i<VCount;++i)
  {
    std::cout << i <<": " << std::endl;
    for(auto it=adjacent[i].begin();it!=adjacent[i].end();++it)
      std::cout << "  " << *it << std::endl;
  }
}

///////////////////////////////////////

void Graph::go(unsigned int v, bool visited[], int w1, int w2)
{
  visited[v] = true; //mark current vertex as visited

  for (auto it = adjacent[v].begin(); it != adjacent[v].end(); ++it) //iterate through adjacent vertices
  {
    if( (int)*it==w1 || (int)*it==w2 ) //skip ignored vertices
      continue;

    if (!visited[*it]) //if vertex not yet visited recursively go from it
      go(*it, visited, w1, w2);
  }
}

///////////////////////////////////////

bool Graph::isConnected(int w1, int w2)
{
  bool visited[VCount]; //bool array for checking connectivity
  for(unsigned int i=0;i<VCount;++i)
    visited[i]=false;

  if(w1>=0)//ignore connectivity to the ignored vertices (if specified)
    visited[w1] = true;
  if(w2>=0)
    visited[w2] = true;

  if(VCount>2)
    go(0,visited,w1,w2);
  else //if graph has 2 vertices and both are ignored assume connectivity
    return true;

  for(unsigned int i = 0;i<VCount;++i) //after traversal check the visited array
    if(!visited[i]) //if at least one element has not been visited the graph is disconnected
      return false;

  return true;
}

///////////////////////////////////////

std::vector<std::pair<unsigned int,unsigned int>> Graph::bridges()
{
  std::vector<std::pair<unsigned int,unsigned int>> found;
  if(VCount<3) //if less than 3 vertices - no possible bridges
    return found;

  for(unsigned int i=0;i<VCount-1;++i) //iterate through every vertex apart from last one
    for(auto j=adjacent[i].begin();j!=adjacent[i].end();++j) //iterate through every vertex's adjacent vertices
    {
      if(*j<i) //if the adjacent vertex's number is smaller then this, connection has already been checked - skip it
        continue;

      if(!isConnected(i,*j)) //check if the graph is still connected without the 2 checked vertices - print them if not
        found.push_back(std::make_pair(i,*j));
    }

  return found;
}

}//namespace
