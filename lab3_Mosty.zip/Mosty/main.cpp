#include "Graph.h"

using namespace std;

void printBridges(vector<pair<unsigned int,unsigned int>> found)
{
  for(auto it=found.begin();it!=found.end();++it)
    cout<< it->first <<" "<< it->second << endl;
}

aisdi::Graph loadGraph()
{
  int v, w;
  std::size_t VCount;

  std::cin >> VCount; //read number of vertices

  aisdi::Graph g(VCount);

  while(std::cin >> v >> w) //mark edges
    g.addEdge(v,w);

  return g;
}

int main(int argc, char** argv)
{
  vector<pair<unsigned int,unsigned int>> found;

  aisdi::Graph g=loadGraph();
  found=g.bridges();
  printBridges(found);

  return 0;
}
